package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class ValueNumericBean {
private static Logger log = Logger.getLogger(ValueNumericBean.class.getName());
    String class="";
    String textContent="";
  public void setClass(String class) { 
		this.class=class;
	} 
    @XmlAttribute(name = "class")
    public String getClass() { 
		return class;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + class;
		}
	}
}