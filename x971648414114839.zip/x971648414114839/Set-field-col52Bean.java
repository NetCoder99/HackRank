package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class Set-field-col52Bean {
private static Logger log = Logger.getLogger(Set-field-col52Bean.class.getName());
    String boundName="";
    String factField="";
    String header="";
    String hideColumn="";
    String type="";
    String update="";
    String width="";
    String textContent="";
@JsonProperty("typedDefaultValue") 
    TypedDefaultValueBean typedDefaultValueBean ;
  public void setBoundName(String boundName) { 
		this.boundName=boundName;
	} 
    @XmlAttribute(name = "boundName")
    public String getBoundName() { 
		return boundName;
	} 
  public void setFactField(String factField) { 
		this.factField=factField;
	} 
    @XmlAttribute(name = "factField")
    public String getFactField() { 
		return factField;
	} 
  public void setHeader(String header) { 
		this.header=header;
	} 
    @XmlAttribute(name = "header")
    public String getHeader() { 
		return header;
	} 
  public void setHideColumn(String hideColumn) { 
		this.hideColumn=hideColumn;
	} 
    @XmlAttribute(name = "hideColumn")
    public String getHideColumn() { 
		return hideColumn;
	} 
  public void setType(String type) { 
		this.type=type;
	} 
    @XmlAttribute(name = "type")
    public String getType() { 
		return type;
	} 
  public void setUpdate(String update) { 
		this.update=update;
	} 
    @XmlAttribute(name = "update")
    public String getUpdate() { 
		return update;
	} 
  public void setWidth(String width) { 
		this.width=width;
	} 
    @XmlAttribute(name = "width")
    public String getWidth() { 
		return width;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
    @XmlElement(name = "typedDefaultValue")
    public TypedDefaultValueBean getTypedDefaultValueBean() { 
		if(typedDefaultValueBean==null) typedDefaultValueBean=new TypedDefaultValueBean(); 
		return typedDefaultValueBean;
	} 
  public void setTypedDefaultValueBean( TypedDefaultValueBean typedDefaultValueBean ) { 
		this.typedDefaultValueBean=typedDefaultValueBean;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + boundName;
		}
	}
}