package com.easy;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
public class BeanToXMLUtil {
public static Document convertBeanToXML (Decision-table52Bean decision-table52Bean) throws Exception {
Document inputDoc = XMLUtil.createDocument("decision-table52");  Element decision-table52Elm=inputDoc.getDocumentElement(); 
decision-table52Elm.setTextContent(decision-table52Bean.getTextContent());


decision-table52Elm.setAttribute("attributeCols",decision-table52Bean.getAttributeCols());
decision-table52Elm.setAttribute("hitPolicy",decision-table52Bean.getHitPolicy());
decision-table52Elm.setAttribute("metadataCols",decision-table52Bean.getMetadataCols());
decision-table52Elm.setAttribute("packageName",decision-table52Bean.getPackageName());
decision-table52Elm.setAttribute("tableFormat",decision-table52Bean.getTableFormat());
decision-table52Elm.setAttribute("tableName",decision-table52Bean.getTableName());
decision-table52Elm.setAttribute("version",decision-table52Bean.getVersion());

Element rowNumberColElm=XMLUtil.createChildElement(decision-table52Elm,"rowNumberCol");
RowNumberColBean rowNumberColBean=decision-table52Bean.getRowNumberColBean();
rowNumberColElm.setTextContent(rowNumberColBean.getTextContent());


rowNumberColElm.setAttribute("hideColumn",rowNumberColBean.getHideColumn());
rowNumberColElm.setAttribute("width",rowNumberColBean.getWidth());

Element descriptionColElm=XMLUtil.createChildElement(decision-table52Elm,"descriptionCol");
DescriptionColBean descriptionColBean=decision-table52Bean.getDescriptionColBean();
descriptionColElm.setTextContent(descriptionColBean.getTextContent());


descriptionColElm.setAttribute("hideColumn",descriptionColBean.getHideColumn());
descriptionColElm.setAttribute("width",descriptionColBean.getWidth());

Element ruleNameColumnElm=XMLUtil.createChildElement(decision-table52Elm,"ruleNameColumn");
RuleNameColumnBean ruleNameColumnBean=decision-table52Bean.getRuleNameColumnBean();
ruleNameColumnElm.setTextContent(ruleNameColumnBean.getTextContent());


ruleNameColumnElm.setAttribute("hideColumn",ruleNameColumnBean.getHideColumn());
ruleNameColumnElm.setAttribute("width",ruleNameColumnBean.getWidth());

Element conditionPatternsElm=XMLUtil.createChildElement(decision-table52Elm,"conditionPatterns");
ConditionPatternsBean conditionPatternsBean=decision-table52Bean.getConditionPatternsBean();
conditionPatternsElm.setTextContent(conditionPatternsBean.getTextContent());



Element pattern52Elm=XMLUtil.createChildElement(conditionPatternsElm,"Pattern52");
Pattern52Bean pattern52Bean=conditionPatternsBean.getPattern52Bean();
pattern52Elm.setTextContent(pattern52Bean.getTextContent());


pattern52Elm.setAttribute("boundName",pattern52Bean.getBoundName());
pattern52Elm.setAttribute("entryPointName",pattern52Bean.getEntryPointName());
pattern52Elm.setAttribute("factType",pattern52Bean.getFactType());
pattern52Elm.setAttribute("isNegated",pattern52Bean.getIsNegated());

Element conditionsElm=XMLUtil.createChildElement(pattern52Elm,"conditions");
ConditionsBean conditionsBean=pattern52Bean.getConditionsBean();
conditionsElm.setTextContent(conditionsBean.getTextContent());



  for (int i=0; i<conditionsBean.getCondition-column52BeanList().size(); i++ ) { 
Condition-column52Bean condition-column52Bean=conditionsBean.getCondition-column52BeanList().get(i); 
  Element condition-column52Elm=XMLUtil.createChildElement(conditionsElm,"condition-column52");
condition-column52Elm.setTextContent(condition-column52Bean.getTextContent());

condition-column52Elm.setAttribute("IsMulti",condition-column52Bean.getIsMulti());
condition-column52Elm.setAttribute("binding",condition-column52Bean.getBinding());
condition-column52Elm.setAttribute("constraintValueType",condition-column52Bean.getConstraintValueType());
condition-column52Elm.setAttribute("factField",condition-column52Bean.getFactField());
condition-column52Elm.setAttribute("fieldType",condition-column52Bean.getFieldType());
condition-column52Elm.setAttribute("header",condition-column52Bean.getHeader());
condition-column52Elm.setAttribute("hideColumn",condition-column52Bean.getHideColumn());
condition-column52Elm.setAttribute("operator",condition-column52Bean.getOperator());
condition-column52Elm.setAttribute("parameters",condition-column52Bean.getParameters());
condition-column52Elm.setAttribute("width",condition-column52Bean.getWidth());

  for (int j=0; j<condition-column52Bean.getTypedDefaultValueBeanList().size(); j++ ) { 
TypedDefaultValueBean typedDefaultValueBean=condition-column52Bean.getTypedDefaultValueBeanList().get(j); 
  Element typedDefaultValueElm=XMLUtil.createChildElement(condition-column52Elm,"typedDefaultValue");
typedDefaultValueElm.setTextContent(typedDefaultValueBean.getTextContent());

typedDefaultValueElm.setAttribute("dataType",typedDefaultValueBean.getDataType());
typedDefaultValueElm.setAttribute("isOtherwise",typedDefaultValueBean.getIsOtherwise());
typedDefaultValueElm.setAttribute("valueString",typedDefaultValueBean.getValueString());

}  
}//REPEAt elm 
Element windowElm=XMLUtil.createChildElement(pattern52Elm,"window");
WindowBean windowBean=pattern52Bean.getWindowBean();
windowElm.setTextContent(windowBean.getTextContent());


windowElm.setAttribute("parameters",windowBean.getParameters());

Element actionColsElm=XMLUtil.createChildElement(decision-table52Elm,"actionCols");
ActionColsBean actionColsBean=decision-table52Bean.getActionColsBean();
actionColsElm.setTextContent(actionColsBean.getTextContent());



Element set-field-col52Elm=XMLUtil.createChildElement(actionColsElm,"set-field-col52");
Set-field-col52Bean set-field-col52Bean=actionColsBean.getSet-field-col52Bean();
set-field-col52Elm.setTextContent(set-field-col52Bean.getTextContent());


set-field-col52Elm.setAttribute("boundName",set-field-col52Bean.getBoundName());
set-field-col52Elm.setAttribute("factField",set-field-col52Bean.getFactField());
set-field-col52Elm.setAttribute("header",set-field-col52Bean.getHeader());
set-field-col52Elm.setAttribute("hideColumn",set-field-col52Bean.getHideColumn());
set-field-col52Elm.setAttribute("type",set-field-col52Bean.getType());
set-field-col52Elm.setAttribute("update",set-field-col52Bean.getUpdate());
set-field-col52Elm.setAttribute("width",set-field-col52Bean.getWidth());

Element typedDefaultValueElm=XMLUtil.createChildElement(set-field-col52Elm,"typedDefaultValue");
TypedDefaultValueBean typedDefaultValueBean=set-field-col52Bean.getTypedDefaultValueBean();
typedDefaultValueElm.setTextContent(typedDefaultValueBean.getTextContent());


typedDefaultValueElm.setAttribute("dataType",typedDefaultValueBean.getDataType());
typedDefaultValueElm.setAttribute("isOtherwise",typedDefaultValueBean.getIsOtherwise());
typedDefaultValueElm.setAttribute("valueString",typedDefaultValueBean.getValueString());

Element auditLogElm=XMLUtil.createChildElement(decision-table52Elm,"auditLog");
AuditLogBean auditLogBean=decision-table52Bean.getAuditLogBean();
auditLogElm.setTextContent(auditLogBean.getTextContent());


auditLogElm.setAttribute("entries",auditLogBean.getEntries());

Element filterElm=XMLUtil.createChildElement(auditLogElm,"filter");
FilterBean filterBean=auditLogBean.getFilterBean();
filterElm.setTextContent(filterBean.getTextContent());


filterElm.setAttribute("class",filterBean.getClass());

Element acceptedTypesElm=XMLUtil.createChildElement(filterElm,"acceptedTypes");
AcceptedTypesBean acceptedTypesBean=filterBean.getAcceptedTypesBean();
acceptedTypesElm.setTextContent(acceptedTypesBean.getTextContent());



  for (int k=0; k<acceptedTypesBean.getEntryBeanList().size(); k++ ) { 
EntryBean entryBean=acceptedTypesBean.getEntryBeanList().get(k); 
  Element entryElm=XMLUtil.createChildElement(acceptedTypesElm,"entry");
entryElm.setTextContent(entryBean.getTextContent());

entryElm.setAttribute("IsMulti",entryBean.getIsMulti());
entryElm.setAttribute("boolean",entryBean.getBoolean());
entryElm.setAttribute("string",entryBean.getString());

}//REPEAt elm 
Element importsElm=XMLUtil.createChildElement(decision-table52Elm,"imports");
ImportsBean importsBean=decision-table52Bean.getImportsBean();
importsElm.setTextContent(importsBean.getTextContent());


importsElm.setAttribute("imports",importsBean.getImports());

Element dataElm=XMLUtil.createChildElement(decision-table52Elm,"data");
DataBean dataBean=decision-table52Bean.getDataBean();
dataElm.setTextContent(dataBean.getTextContent());



  for (int l=0; l<dataBean.getListBeanList().size(); l++ ) { 
ListBean listBean=dataBean.getListBeanList().get(l); 
  Element listElm=XMLUtil.createChildElement(dataElm,"list");
listElm.setTextContent(listBean.getTextContent());

listElm.setAttribute("IsMulti",listBean.getIsMulti());

  for (int m=0; m<listBean.getValueBeanList().size(); m++ ) { 
ValueBean valueBean=listBean.getValueBeanList().get(m); 
  Element valueElm=XMLUtil.createChildElement(listElm,"value");
valueElm.setTextContent(valueBean.getTextContent());

valueElm.setAttribute("IsMulti",valueBean.getIsMulti());
valueElm.setAttribute("dataType",valueBean.getDataType());
valueElm.setAttribute("isOtherwise",valueBean.getIsOtherwise());
valueElm.setAttribute("valueString",valueBean.getValueString());

  for (int n=0; n<valueBean.getValueNumericBeanList().size(); n++ ) { 
ValueNumericBean valueNumericBean=valueBean.getValueNumericBeanList().get(n); 
  Element valueNumericElm=XMLUtil.createChildElement(valueElm,"valueNumeric");
valueNumericElm.setTextContent(valueNumericBean.getTextContent());

valueNumericElm.setAttribute("class",valueNumericBean.getClass());

}  
}  
}//REPEAt elm 
 
 return inputDoc; 
 } 
 }