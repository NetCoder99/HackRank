package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class Decision-table52Bean {
private static Logger log = Logger.getLogger(Decision-table52Bean.class.getName());
    String attributeCols="";
    String hitPolicy="";
    String metadataCols="";
    String packageName="";
    String tableFormat="";
    String tableName="";
    String version="";
    String textContent="";
@JsonProperty("rowNumberCol") 
    RowNumberColBean rowNumberColBean ;
@JsonProperty("descriptionCol") 
    DescriptionColBean descriptionColBean ;
@JsonProperty("ruleNameColumn") 
    RuleNameColumnBean ruleNameColumnBean ;
@JsonProperty("conditionPatterns") 
    ConditionPatternsBean conditionPatternsBean ;
@JsonProperty("actionCols") 
    ActionColsBean actionColsBean ;
@JsonProperty("auditLog") 
    AuditLogBean auditLogBean ;
@JsonProperty("imports") 
    ImportsBean importsBean ;
@JsonProperty("data") 
    DataBean dataBean ;
  public void setAttributeCols(String attributeCols) { 
		this.attributeCols=attributeCols;
	} 
    @XmlAttribute(name = "attributeCols")
    public String getAttributeCols() { 
		return attributeCols;
	} 
  public void setHitPolicy(String hitPolicy) { 
		this.hitPolicy=hitPolicy;
	} 
    @XmlAttribute(name = "hitPolicy")
    public String getHitPolicy() { 
		return hitPolicy;
	} 
  public void setMetadataCols(String metadataCols) { 
		this.metadataCols=metadataCols;
	} 
    @XmlAttribute(name = "metadataCols")
    public String getMetadataCols() { 
		return metadataCols;
	} 
  public void setPackageName(String packageName) { 
		this.packageName=packageName;
	} 
    @XmlAttribute(name = "packageName")
    public String getPackageName() { 
		return packageName;
	} 
  public void setTableFormat(String tableFormat) { 
		this.tableFormat=tableFormat;
	} 
    @XmlAttribute(name = "tableFormat")
    public String getTableFormat() { 
		return tableFormat;
	} 
  public void setTableName(String tableName) { 
		this.tableName=tableName;
	} 
    @XmlAttribute(name = "tableName")
    public String getTableName() { 
		return tableName;
	} 
  public void setVersion(String version) { 
		this.version=version;
	} 
    @XmlAttribute(name = "version")
    public String getVersion() { 
		return version;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
    @XmlElement(name = "rowNumberCol")
    public RowNumberColBean getRowNumberColBean() { 
		if(rowNumberColBean==null) rowNumberColBean=new RowNumberColBean(); 
		return rowNumberColBean;
	} 
  public void setRowNumberColBean( RowNumberColBean rowNumberColBean ) { 
		this.rowNumberColBean=rowNumberColBean;
	} 
    @XmlElement(name = "descriptionCol")
    public DescriptionColBean getDescriptionColBean() { 
		if(descriptionColBean==null) descriptionColBean=new DescriptionColBean(); 
		return descriptionColBean;
	} 
  public void setDescriptionColBean( DescriptionColBean descriptionColBean ) { 
		this.descriptionColBean=descriptionColBean;
	} 
    @XmlElement(name = "ruleNameColumn")
    public RuleNameColumnBean getRuleNameColumnBean() { 
		if(ruleNameColumnBean==null) ruleNameColumnBean=new RuleNameColumnBean(); 
		return ruleNameColumnBean;
	} 
  public void setRuleNameColumnBean( RuleNameColumnBean ruleNameColumnBean ) { 
		this.ruleNameColumnBean=ruleNameColumnBean;
	} 
    @XmlElement(name = "conditionPatterns")
    public ConditionPatternsBean getConditionPatternsBean() { 
		if(conditionPatternsBean==null) conditionPatternsBean=new ConditionPatternsBean(); 
		return conditionPatternsBean;
	} 
  public void setConditionPatternsBean( ConditionPatternsBean conditionPatternsBean ) { 
		this.conditionPatternsBean=conditionPatternsBean;
	} 
    @XmlElement(name = "actionCols")
    public ActionColsBean getActionColsBean() { 
		if(actionColsBean==null) actionColsBean=new ActionColsBean(); 
		return actionColsBean;
	} 
  public void setActionColsBean( ActionColsBean actionColsBean ) { 
		this.actionColsBean=actionColsBean;
	} 
    @XmlElement(name = "auditLog")
    public AuditLogBean getAuditLogBean() { 
		if(auditLogBean==null) auditLogBean=new AuditLogBean(); 
		return auditLogBean;
	} 
  public void setAuditLogBean( AuditLogBean auditLogBean ) { 
		this.auditLogBean=auditLogBean;
	} 
    @XmlElement(name = "imports")
    public ImportsBean getImportsBean() { 
		if(importsBean==null) importsBean=new ImportsBean(); 
		return importsBean;
	} 
  public void setImportsBean( ImportsBean importsBean ) { 
		this.importsBean=importsBean;
	} 
    @XmlElement(name = "data")
    public DataBean getDataBean() { 
		if(dataBean==null) dataBean=new DataBean(); 
		return dataBean;
	} 
  public void setDataBean( DataBean dataBean ) { 
		this.dataBean=dataBean;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + attributeCols;
		}
	}
}