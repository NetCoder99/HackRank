package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class Pattern52Bean {
private static Logger log = Logger.getLogger(Pattern52Bean.class.getName());
    String boundName="";
    String entryPointName="";
    String factType="";
    String isNegated="";
    String textContent="";
@JsonProperty("conditions") 
    ConditionsBean conditionsBean ;
@JsonProperty("window") 
    WindowBean windowBean ;
  public void setBoundName(String boundName) { 
		this.boundName=boundName;
	} 
    @XmlAttribute(name = "boundName")
    public String getBoundName() { 
		return boundName;
	} 
  public void setEntryPointName(String entryPointName) { 
		this.entryPointName=entryPointName;
	} 
    @XmlAttribute(name = "entryPointName")
    public String getEntryPointName() { 
		return entryPointName;
	} 
  public void setFactType(String factType) { 
		this.factType=factType;
	} 
    @XmlAttribute(name = "factType")
    public String getFactType() { 
		return factType;
	} 
  public void setIsNegated(String isNegated) { 
		this.isNegated=isNegated;
	} 
    @XmlAttribute(name = "isNegated")
    public String getIsNegated() { 
		return isNegated;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
    @XmlElement(name = "conditions")
    public ConditionsBean getConditionsBean() { 
		if(conditionsBean==null) conditionsBean=new ConditionsBean(); 
		return conditionsBean;
	} 
  public void setConditionsBean( ConditionsBean conditionsBean ) { 
		this.conditionsBean=conditionsBean;
	} 
    @XmlElement(name = "window")
    public WindowBean getWindowBean() { 
		if(windowBean==null) windowBean=new WindowBean(); 
		return windowBean;
	} 
  public void setWindowBean( WindowBean windowBean ) { 
		this.windowBean=windowBean;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + boundName;
		}
	}
}