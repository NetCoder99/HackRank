package com.easy;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
public class XMLToBeanObjUtil {
private static Decision-table52Bean convertXmlToBeanObject(Document doc ) throws Exception { 

		Element decision-table52Elm = doc.getDocumentElement();Decision-table52Bean decision-table52Bean = new Decision-table52Bean();


decision-table52Bean.setAttributeCols(decision-table52Elm.getAttribute("attributeCols"));
decision-table52Bean.setHitPolicy(decision-table52Elm.getAttribute("hitPolicy"));
decision-table52Bean.setMetadataCols(decision-table52Elm.getAttribute("metadataCols"));
decision-table52Bean.setPackageName(decision-table52Elm.getAttribute("packageName"));
decision-table52Bean.setTableFormat(decision-table52Elm.getAttribute("tableFormat"));
decision-table52Bean.setTableName(decision-table52Elm.getAttribute("tableName"));
decision-table52Bean.setVersion(decision-table52Elm.getAttribute("version"));
decision-table52Bean.setTextContent(XMLUtil.getFirstLevelTextContent(decision-table52Elm));

		Element rowNumberColElm = XMLUtil.getChildElement(decision-table52Elm, "rowNumberCol");
RowNumberColBean rowNumberColBean = new RowNumberColBean();
decision-table52Bean.setRowNumberColBean(rowNumberColBean);


rowNumberColBean.setHideColumn(rowNumberColElm.getAttribute("hideColumn"));
rowNumberColBean.setWidth(rowNumberColElm.getAttribute("width"));
rowNumberColBean.setTextContent(XMLUtil.getFirstLevelTextContent(rowNumberColElm));

		Element descriptionColElm = XMLUtil.getChildElement(decision-table52Elm, "descriptionCol");
DescriptionColBean descriptionColBean = new DescriptionColBean();
decision-table52Bean.setDescriptionColBean(descriptionColBean);


descriptionColBean.setHideColumn(descriptionColElm.getAttribute("hideColumn"));
descriptionColBean.setWidth(descriptionColElm.getAttribute("width"));
descriptionColBean.setTextContent(XMLUtil.getFirstLevelTextContent(descriptionColElm));

		Element ruleNameColumnElm = XMLUtil.getChildElement(decision-table52Elm, "ruleNameColumn");
RuleNameColumnBean ruleNameColumnBean = new RuleNameColumnBean();
decision-table52Bean.setRuleNameColumnBean(ruleNameColumnBean);


ruleNameColumnBean.setHideColumn(ruleNameColumnElm.getAttribute("hideColumn"));
ruleNameColumnBean.setWidth(ruleNameColumnElm.getAttribute("width"));
ruleNameColumnBean.setTextContent(XMLUtil.getFirstLevelTextContent(ruleNameColumnElm));

		Element conditionPatternsElm = XMLUtil.getChildElement(decision-table52Elm, "conditionPatterns");
ConditionPatternsBean conditionPatternsBean = new ConditionPatternsBean();
decision-table52Bean.setConditionPatternsBean(conditionPatternsBean);


conditionPatternsBean.setTextContent(XMLUtil.getFirstLevelTextContent(conditionPatternsElm));

		Element pattern52Elm = XMLUtil.getChildElement(conditionPatternsElm, "Pattern52");
Pattern52Bean pattern52Bean = new Pattern52Bean();
conditionPatternsBean.setPattern52Bean(pattern52Bean);


pattern52Bean.setBoundName(pattern52Elm.getAttribute("boundName"));
pattern52Bean.setEntryPointName(pattern52Elm.getAttribute("entryPointName"));
pattern52Bean.setFactType(pattern52Elm.getAttribute("factType"));
pattern52Bean.setIsNegated(pattern52Elm.getAttribute("isNegated"));
pattern52Bean.setTextContent(XMLUtil.getFirstLevelTextContent(pattern52Elm));

		Element conditionsElm = XMLUtil.getChildElement(pattern52Elm, "conditions");
ConditionsBean conditionsBean = new ConditionsBean();
pattern52Bean.setConditionsBean(conditionsBean);


conditionsBean.setTextContent(XMLUtil.getFirstLevelTextContent(conditionsElm));

		List<Element> condition-column52NdList = XMLUtil.getChildElements(conditionsElm, "condition-column52");
List<Condition-column52Bean> condition-column52BeanList = new ArrayList<Condition-column52Bean> ();
conditionsBean.setCondition-column52BeanList (condition-column52BeanList); 
		for (Element condition-column52Elm: condition-column52NdList) {
Condition-column52Bean condition-column52Bean = new Condition-column52Bean();
condition-column52BeanList.add(condition-column52Bean);

condition-column52Bean.setIsMulti(condition-column52Elm.getAttribute("IsMulti"));
condition-column52Bean.setBinding(condition-column52Elm.getAttribute("binding"));
condition-column52Bean.setConstraintValueType(condition-column52Elm.getAttribute("constraintValueType"));
condition-column52Bean.setFactField(condition-column52Elm.getAttribute("factField"));
condition-column52Bean.setFieldType(condition-column52Elm.getAttribute("fieldType"));
condition-column52Bean.setHeader(condition-column52Elm.getAttribute("header"));
condition-column52Bean.setHideColumn(condition-column52Elm.getAttribute("hideColumn"));
condition-column52Bean.setOperator(condition-column52Elm.getAttribute("operator"));
condition-column52Bean.setParameters(condition-column52Elm.getAttribute("parameters"));
condition-column52Bean.setWidth(condition-column52Elm.getAttribute("width"));

		List<Element> typedDefaultValueNdList = XMLUtil.getChildElements(condition-column52Elm, "typedDefaultValue");
List<TypedDefaultValueBean> typedDefaultValueBeanList = new ArrayList<TypedDefaultValueBean> ();
condition-column52Bean.setTypedDefaultValueBeanList (typedDefaultValueBeanList); 
		for (Element typedDefaultValueElm: typedDefaultValueNdList) {
TypedDefaultValueBean typedDefaultValueBean = new TypedDefaultValueBean();
typedDefaultValueBeanList.add(typedDefaultValueBean);

typedDefaultValueBean.setDataType(typedDefaultValueElm.getAttribute("dataType"));
typedDefaultValueBean.setIsOtherwise(typedDefaultValueElm.getAttribute("isOtherwise"));
typedDefaultValueBean.setValueString(typedDefaultValueElm.getAttribute("valueString"));

} 
} 
		Element windowElm = XMLUtil.getChildElement(pattern52Elm, "window");
WindowBean windowBean = new WindowBean();
pattern52Bean.setWindowBean(windowBean);


windowBean.setParameters(windowElm.getAttribute("parameters"));
windowBean.setTextContent(XMLUtil.getFirstLevelTextContent(windowElm));

		Element actionColsElm = XMLUtil.getChildElement(decision-table52Elm, "actionCols");
ActionColsBean actionColsBean = new ActionColsBean();
decision-table52Bean.setActionColsBean(actionColsBean);


actionColsBean.setTextContent(XMLUtil.getFirstLevelTextContent(actionColsElm));

		Element set-field-col52Elm = XMLUtil.getChildElement(actionColsElm, "set-field-col52");
Set-field-col52Bean set-field-col52Bean = new Set-field-col52Bean();
actionColsBean.setSet-field-col52Bean(set-field-col52Bean);


set-field-col52Bean.setBoundName(set-field-col52Elm.getAttribute("boundName"));
set-field-col52Bean.setFactField(set-field-col52Elm.getAttribute("factField"));
set-field-col52Bean.setHeader(set-field-col52Elm.getAttribute("header"));
set-field-col52Bean.setHideColumn(set-field-col52Elm.getAttribute("hideColumn"));
set-field-col52Bean.setType(set-field-col52Elm.getAttribute("type"));
set-field-col52Bean.setUpdate(set-field-col52Elm.getAttribute("update"));
set-field-col52Bean.setWidth(set-field-col52Elm.getAttribute("width"));
set-field-col52Bean.setTextContent(XMLUtil.getFirstLevelTextContent(set-field-col52Elm));

		Element typedDefaultValueElm = XMLUtil.getChildElement(set-field-col52Elm, "typedDefaultValue");
TypedDefaultValueBean typedDefaultValueBean = new TypedDefaultValueBean();
set-field-col52Bean.setTypedDefaultValueBean(typedDefaultValueBean);


typedDefaultValueBean.setDataType(typedDefaultValueElm.getAttribute("dataType"));
typedDefaultValueBean.setIsOtherwise(typedDefaultValueElm.getAttribute("isOtherwise"));
typedDefaultValueBean.setValueString(typedDefaultValueElm.getAttribute("valueString"));
typedDefaultValueBean.setTextContent(XMLUtil.getFirstLevelTextContent(typedDefaultValueElm));

		Element auditLogElm = XMLUtil.getChildElement(decision-table52Elm, "auditLog");
AuditLogBean auditLogBean = new AuditLogBean();
decision-table52Bean.setAuditLogBean(auditLogBean);


auditLogBean.setEntries(auditLogElm.getAttribute("entries"));
auditLogBean.setTextContent(XMLUtil.getFirstLevelTextContent(auditLogElm));

		Element filterElm = XMLUtil.getChildElement(auditLogElm, "filter");
FilterBean filterBean = new FilterBean();
auditLogBean.setFilterBean(filterBean);


filterBean.setClass(filterElm.getAttribute("class"));
filterBean.setTextContent(XMLUtil.getFirstLevelTextContent(filterElm));

		Element acceptedTypesElm = XMLUtil.getChildElement(filterElm, "acceptedTypes");
AcceptedTypesBean acceptedTypesBean = new AcceptedTypesBean();
filterBean.setAcceptedTypesBean(acceptedTypesBean);


acceptedTypesBean.setTextContent(XMLUtil.getFirstLevelTextContent(acceptedTypesElm));

		List<Element> entryNdList = XMLUtil.getChildElements(acceptedTypesElm, "entry");
List<EntryBean> entryBeanList = new ArrayList<EntryBean> ();
acceptedTypesBean.setEntryBeanList (entryBeanList); 
		for (Element entryElm: entryNdList) {
EntryBean entryBean = new EntryBean();
entryBeanList.add(entryBean);

entryBean.setIsMulti(entryElm.getAttribute("IsMulti"));
entryBean.setBoolean(entryElm.getAttribute("boolean"));
entryBean.setString(entryElm.getAttribute("string"));

} 
		Element importsElm = XMLUtil.getChildElement(decision-table52Elm, "imports");
ImportsBean importsBean = new ImportsBean();
decision-table52Bean.setImportsBean(importsBean);


importsBean.setImports(importsElm.getAttribute("imports"));
importsBean.setTextContent(XMLUtil.getFirstLevelTextContent(importsElm));

		Element dataElm = XMLUtil.getChildElement(decision-table52Elm, "data");
DataBean dataBean = new DataBean();
decision-table52Bean.setDataBean(dataBean);


dataBean.setTextContent(XMLUtil.getFirstLevelTextContent(dataElm));

		List<Element> listNdList = XMLUtil.getChildElements(dataElm, "list");
List<ListBean> listBeanList = new ArrayList<ListBean> ();
dataBean.setListBeanList (listBeanList); 
		for (Element listElm: listNdList) {
ListBean listBean = new ListBean();
listBeanList.add(listBean);

listBean.setIsMulti(listElm.getAttribute("IsMulti"));

		List<Element> valueNdList = XMLUtil.getChildElements(listElm, "value");
List<ValueBean> valueBeanList = new ArrayList<ValueBean> ();
listBean.setValueBeanList (valueBeanList); 
		for (Element valueElm: valueNdList) {
ValueBean valueBean = new ValueBean();
valueBeanList.add(valueBean);

valueBean.setIsMulti(valueElm.getAttribute("IsMulti"));
valueBean.setDataType(valueElm.getAttribute("dataType"));
valueBean.setIsOtherwise(valueElm.getAttribute("isOtherwise"));
valueBean.setValueString(valueElm.getAttribute("valueString"));

		List<Element> valueNumericNdList = XMLUtil.getChildElements(valueElm, "valueNumeric");
List<ValueNumericBean> valueNumericBeanList = new ArrayList<ValueNumericBean> ();
valueBean.setValueNumericBeanList (valueNumericBeanList); 
		for (Element valueNumericElm: valueNumericNdList) {
ValueNumericBean valueNumericBean = new ValueNumericBean();
valueNumericBeanList.add(valueNumericBean);

valueNumericBean.setClass(valueNumericElm.getAttribute("class"));

} 
} 
} 

 return decision-table52Bean; 
 } 
 }