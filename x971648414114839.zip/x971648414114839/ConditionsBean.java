package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class ConditionsBean {
private static Logger log = Logger.getLogger(ConditionsBean.class.getName());
    String textContent="";
@JsonProperty("condition-column52") 
    List< Condition-column52Bean> condition-column52BeanList ;
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
  public void setCondition-column52BeanList(List<Condition-column52Bean> condition-column52BeanList) { 
		this.condition-column52BeanList=condition-column52BeanList;
	} 
	@XmlElement(name = "condition-column52")
public List<Condition-column52Bean> getCondition-column52BeanList() { 
		if(condition-column52BeanList == null)
		condition-column52BeanList=new ArrayList<Condition-column52Bean>(); 
		return condition-column52BeanList;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return "" ;
		}
	}
}