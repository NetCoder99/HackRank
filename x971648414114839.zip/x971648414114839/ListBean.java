package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class ListBean {
private static Logger log = Logger.getLogger(ListBean.class.getName());
    String isMulti="";
    String textContent="";
@JsonProperty("value") 
    List< ValueBean> valueBeanList ;
  public void setIsMulti(String isMulti) { 
		this.isMulti=isMulti;
	} 
    @XmlAttribute(name = "IsMulti")
    public String getIsMulti() { 
		return isMulti;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
  public void setValueBeanList(List<ValueBean> valueBeanList) { 
		this.valueBeanList=valueBeanList;
	} 
	@XmlElement(name = "value")
public List<ValueBean> getValueBeanList() { 
		if(valueBeanList == null)
		valueBeanList=new ArrayList<ValueBean>(); 
		return valueBeanList;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + isMulti;
		}
	}
}