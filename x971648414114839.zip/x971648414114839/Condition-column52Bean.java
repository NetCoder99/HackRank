package com.easy;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.*;

import org.apache.log4j.*;

public class Condition-column52Bean {
private static Logger log = Logger.getLogger(Condition-column52Bean.class.getName());
    String isMulti="";
    String binding="";
    String constraintValueType="";
    String factField="";
    String fieldType="";
    String header="";
    String hideColumn="";
    String operator="";
    String parameters="";
    String width="";
    String textContent="";
@JsonProperty("typedDefaultValue") 
    TypedDefaultValueBean typedDefaultValueBean ;
  public void setIsMulti(String isMulti) { 
		this.isMulti=isMulti;
	} 
    @XmlAttribute(name = "IsMulti")
    public String getIsMulti() { 
		return isMulti;
	} 
  public void setBinding(String binding) { 
		this.binding=binding;
	} 
    @XmlAttribute(name = "binding")
    public String getBinding() { 
		return binding;
	} 
  public void setConstraintValueType(String constraintValueType) { 
		this.constraintValueType=constraintValueType;
	} 
    @XmlAttribute(name = "constraintValueType")
    public String getConstraintValueType() { 
		return constraintValueType;
	} 
  public void setFactField(String factField) { 
		this.factField=factField;
	} 
    @XmlAttribute(name = "factField")
    public String getFactField() { 
		return factField;
	} 
  public void setFieldType(String fieldType) { 
		this.fieldType=fieldType;
	} 
    @XmlAttribute(name = "fieldType")
    public String getFieldType() { 
		return fieldType;
	} 
  public void setHeader(String header) { 
		this.header=header;
	} 
    @XmlAttribute(name = "header")
    public String getHeader() { 
		return header;
	} 
  public void setHideColumn(String hideColumn) { 
		this.hideColumn=hideColumn;
	} 
    @XmlAttribute(name = "hideColumn")
    public String getHideColumn() { 
		return hideColumn;
	} 
  public void setOperator(String operator) { 
		this.operator=operator;
	} 
    @XmlAttribute(name = "operator")
    public String getOperator() { 
		return operator;
	} 
  public void setParameters(String parameters) { 
		this.parameters=parameters;
	} 
    @XmlAttribute(name = "parameters")
    public String getParameters() { 
		return parameters;
	} 
  public void setWidth(String width) { 
		this.width=width;
	} 
    @XmlAttribute(name = "width")
    public String getWidth() { 
		return width;
	} 
  public void setTextContent(String textContent) { 
		this.textContent=textContent;
	} 
    @XmlAttribute(name = "TextContent")
    public String getTextContent() { 
		return textContent;
	} 
    @XmlElement(name = "typedDefaultValue")
    public TypedDefaultValueBean getTypedDefaultValueBean() { 
		if(typedDefaultValueBean==null) typedDefaultValueBean=new TypedDefaultValueBean(); 
		return typedDefaultValueBean;
	} 
  public void setTypedDefaultValueBean( TypedDefaultValueBean typedDefaultValueBean ) { 
		this.typedDefaultValueBean=typedDefaultValueBean;
	} 

	@Override
	public String toString() {
		if (log.isDebugEnabled()) {
			String str = "";
			// Converts object to json string using GSON
			// Gson gson = new Gson();
			// str = gson.toJson(this);
			
			//Converts object to json string using Jaxson
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				str = mapper.writeValueAsString(this);
			} catch (Exception exception) {
				log.error(exception);
			}
			return str;
		} else {
			return ""  + isMulti;
		}
	}
}